
 function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}

function openjadNav() {
  document.getElementById("jadSidenav").style.width = "330px";
}

function closejadNav() {
  document.getElementById("jadSidenav").style.width = "0";
}